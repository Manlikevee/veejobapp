import React from 'react'

const MySpinner = () => {
  return (
    <div className="simple-spinner">
    <span />
  </div>
  
  )
}

export default MySpinner